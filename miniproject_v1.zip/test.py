from flask import Flask
from flask import request, render_template, redirect, url_for
from sklearn.feature_extraction.text import TfidfVectorizer
from konlpy.tag import Twitter
import numpy as np

app = Flask(__name__)


@app.route('/')
def FirstPage():
    return render_template("template.html")


@app.route('/result', methods=['POST'])
def Result():
    tfidfvectorizer = TfidfVectorizer()
    twitter = Twitter()
    data1 = request.form.get('textarea1')
    data2 = request.form.get('textarea2')

    str1_sentences = data1.replace('다.', '다.&split&').split('&split&')[:-1]
    str2_sentences = data2.replace('다.', '다.&split&').split('&split&')[:-1]

    str1_len = len(str1_sentences)
    str2_len = len(str2_sentences)

    all_sentences = str1_sentences + str2_sentences

    mydoc_list = []
    for sentence in all_sentences:
        mydoc_list.append(' '.join([val[0] for val in twitter.pos(sentence, stem=True)]))

    mydoc_matrix = tfidfvectorizer.fit_transform(mydoc_list)
    cosine_similarity = (mydoc_matrix * mydoc_matrix.T).toarray()[:, :str1_len]

    similarity_list = []
    for i in range(str1_len, cosine_similarity.shape[0]):
        for j in np.where(cosine_similarity[i] > 0.5)[0]:
            if all_sentences[i][:6] != '<mark>':
                all_sentences[i] = '<mark>' + all_sentences[i] + '</mark>'
            if all_sentences[j][:6] != '<mark>':
                all_sentences[j] = '<mark>' + all_sentences[j] + '</mark>'

    mylist = []
    pos_result1 = twitter.pos(data1, stem=True)
    pos_result2 = twitter.pos(data2, stem=True)

    mylist.append(' '.join([val[0] for val in pos_result1]))
    mylist.append(' '.join([val[0] for val in pos_result2]))

    mylist.append(' '.join(twitter.nouns(data1)))
    mylist.append(' '.join(twitter.nouns(data2)))

    print(mylist)
    tfidf_matrix = tfidfvectorizer.fit_transform(mylist)
    document_distances = (tfidf_matrix * tfidf_matrix.T).toarray()
    print(document_distances[0][1])

    score = (round(document_distances[0][1], 2)) * 100

    result = data1 + data2
    print(result)
    return render_template("result.html", result1=' '.join(all_sentences[:str1_len]),
                           result2=' '.join(all_sentences[str1_len:]), score=score)


if __name__ == '__main__':
    app.run(debug=True)
