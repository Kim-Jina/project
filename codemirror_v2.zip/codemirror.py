from flask import Flask, request, render_template, jsonify, redirect

app = Flask(__name__)


@app.route('/')
def calendar():
    return render_template("main.html")


@app.route('/submit', methods=['POST'])
def submit():
    language_list = ['c-code', 'cpp-code', 'java-code', 'objectivec-code', 'scala-code', 'kotlin-code', 'ceylon-code']
    code_list = []

    for language in language_list:
        code_list.append(request.form.get(language))

    print('Language List : %s' % str(language_list))
    lang = input('출력하고자 하는 언어 입력 : ')

    code_idx = language_list.index(lang)
    print(code_list[code_idx])

    return redirect("http://127.0.0.1:5000/")


if __name__ == '__main__':
    app.debug = True
    app.run()
